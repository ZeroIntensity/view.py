__version__ = "1.0.0-alpha1"
__license__ = "MIT"
